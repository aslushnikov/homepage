package engine;

import java.io.Serializable;

public class NetMessage implements Serializable {
	public static final int YES = 1;
	public static final int NO = 2;
	public static final int SWAP_SIDES = 3;
	public static final int REPEAT_GAME = 4;
	public static final int INTERRUPT_GAME = 5;
	public static final int CLOSE_CONNECTION = 6;
	public static final int MOVE = 7;
	public static final int CHAT_MESSAGE = 8;
	
	private int msgType;
	private Object info;
	
	public NetMessage(int type){
		info = null;
		msgType = type;
	}
	public NetMessage(int type, Object info){
		this.info = info;
		msgType = type;
	}
	
	public int type(){
		return msgType;
	}
	
	public Object info(){
		return this.info;
	}
}
