package ai;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import engine.Field;

public class MediumAI implements ArtificialIntelligence {

	private volatile boolean running;
	
	public String getInformation() {
		return null;
	}

	public String getName() {
		return null;
	}

	private Field field = null;

	private ArrayList<Point> shapeX2 = null, shapeX1 = null;

	private boolean anyNeibourX2(Field field, int x, int y) {
		for (int k = -2; k <= 2; k++) {
			for (int l = -2; l <= 2; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) != Field.EMPTY)
						return true;
				}
			}
		}

		return false;
	}
	
	private boolean anyNeibourX1(Field field, int x, int y) {
		for (int k = -1; k <= 1; k++) {
			for (int l = -1; l <= 1; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) != Field.EMPTY)
						return true;
				}
			}
		}

		return false;
	}	

	private void createShape() {
		shapeX1 = new ArrayList<Point>();
		shapeX2 = new ArrayList<Point>();
		for (int i = 0; i < Field.SIZE; i++) {
			for (int j = 0; j < Field.SIZE; j++) {
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				if (anyNeibourX2(field, j, i))
					shapeX2.add(new Point(j, i));
				if (anyNeibourX1(field, j, i))
					shapeX1.add(new Point(j, i));
			}
		}
	}

	private boolean canWin() {
		for (Point p : shapeX1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
				tmp.move(i, j);
			if (tmp.fiveInRaw())
				return true;

		}
		return false;
	}

	private Point win() {
		for (Point p : shapeX1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
				tmp.move(i, j);
			if (tmp.fiveInRaw())
				return new Point(j, i);
		}
		return null;
	}

	private boolean canLose() {
		for (Point p : shapeX1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			if (tmp.getCurrentMove() == Field.CROSS) {
				tmp.setCurrentMove(Field.ZERO);
			} else {
				tmp.setCurrentMove(Field.CROSS);
			}
				tmp.move(i, j);
			if (tmp.fiveInRaw())
				return true;
		}

		return false;
	}

	private Point doNotLose() {
		for (Point p : shapeX1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			if (tmp.getCurrentMove() == Field.CROSS) {
				tmp.setCurrentMove(Field.ZERO);
			} else {
				tmp.setCurrentMove(Field.CROSS);
			}
				tmp.move(i, j);
			if (tmp.fiveInRaw())
				return new Point(j, i);
		}

		return null;
	}

	private int winningMoves(Field field) {
		int result = 0;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
				tmp.move(i, j);
			if (tmp.fiveInRaw())
				result += 1;
		}

		return result;
	}

	private Point attackBuildOpened4() {
		Point result = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
				tmp.move(i, j);
			if (winningMoves(tmp) > 1)
				if (result == null) result = new Point(j, i); else
					if (new Random().nextInt() % 2 == 0) result = new Point(j, i); 
		}

		return result;
	}

	private Point defendBuildOpened4() {
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			if (tmp.getCurrentMove() == Field.CROSS) {
				tmp.setCurrentMove(Field.ZERO);
			} else {
				tmp.setCurrentMove(Field.CROSS);
			}
				tmp.move(i, j);
			if (winningMoves(tmp) > 1)
				return new Point(j, i);
		}

		return null;
	}
	
	private Point canGrow(){
		Point result = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
				tmp.move(i, j);
			if (winningMoves(tmp) == 1)
				if (result == null) result = new Point(j, i); else
					if (new Random().nextInt() % 2 == 0) result = new Point(j, i); 
		}

		return result;
	}

	private int countNeibours(Field field, int x, int y, int type) {
		int result = 0;

		for (int k = -1; k <= 1; k++) {
			for (int l = -1; l <= 1; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) == type)
						result += 1;
				}
			}
		}

		return result;
	}

	private Point putInPosition() {
		int zBestN = -1;
		Point zBestP = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			// Field tmp = (Field)field.clone();
			int type = field.getCurrentMove();
			if (type == Field.CROSS) {
				type = Field.ZERO;
			} else {
				type = Field.CROSS;
			}

			int n = countNeibours(field, j, i, type);
			if (n > zBestN) {
				zBestN = n;
				zBestP = new Point(j, i);
			} else
				if ((n == zBestN) && (new Random().nextInt() % 2 == 0)){
					zBestN = n;
					zBestP = new Point(j, i);					
				}
		}

		int cBestN = -1;
		Point cBestP = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			// Field tmp = (Field)field.clone();
			int type = field.getCurrentMove();

			int n = countNeibours(field, j, i, type);
			if (n > cBestN) {
				cBestN = n;
				cBestP = new Point(j, i);
			} else
				if ((n == cBestN) && (new Random().nextInt() % 2 == 0)){
					cBestN = n;
					cBestP = new Point(j, i);					
				}
		}
		
		
//		System.out.println("best N is " + zBestN);
		
		if ((cBestN >= zBestN) && (cBestN != -1)) return cBestP;
		
		if (zBestN == -1) {
			zBestP = new Point(Field.SIZE / 2, Field.SIZE / 2);
		}
		
		return zBestP;
	}
	
	private int countHalfOpened4(Field field, int type){
		int result = 0;
		ArrayList<Point> shapeX1 = new ArrayList<Point>();
		for (int i = 0; i < Field.SIZE; i++) {
			for (int j = 0; j < Field.SIZE; j++) {
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				if (anyNeibourX1(field, j, i))
					shapeX1.add(new Point(j, i));
			}
		}

		
		
		for(Point p : shapeX1){
		    int i = p.y;
		    int j = p.x;
		    
		    if (field.getValue(i, j) != Field.EMPTY) continue;
		    
		    Field tmp = (Field)field.clone();
		    tmp.setCurrentMove(type);
				tmp.move(i, j);
				if (type == Field.CROSS) {
					if (tmp.fiveCrossesInRaw()) result += 1;
				} else {
					if (tmp.fiveZeroesInRaw()) result += 1;					
				}
		}
		
		return result;
	}
	
	private Point combination(int type){
		int[][] mx = field.getMatrix();

		// ���������� ��� ������ ���
		for(Point cMove1 : shapeX2){
//			boolean win = true;
			
			mx[cMove1.y][cMove1.x] = type;
			
			// ���������� ������������ ������
/*			for(Point zMove1 : shapeX2){
				
				if (mx[zMove1.y][zMove1.x] != Field.EMPTY) continue;
				
				boolean defend = true;
				
				if (type == Field.CROSS) mx[zMove1.y][zMove1.x] = Field.ZERO; else
					mx[zMove1.y][zMove1.x] = Field.CROSS;*/
				
				// ���������� ��� ������ ���
				int temp = 0;
				for(Point cMove2 : shapeX1){
					if (mx[cMove2.y][cMove2.x] != Field.EMPTY) continue;

					mx[cMove2.y][cMove2.x] = type;
					
					Field f3 = new Field(mx, type);
					
					mx[cMove2.y][cMove2.x] = Field.EMPTY;
					
					if (countHalfOpened4(f3, type) > 1){
						temp += 1;
					}
					
				}
/*				mx[zMove1.y][zMove1.x] = Field.EMPTY;
				
				if (defend){
					win = false;
					break;
				}
			}*/
			mx[cMove1.y][cMove1.x] = Field.EMPTY;
			if (temp > 1){
				return cMove1;
			}
		}
		return null;
	}
	
	private int countOpened4(Field field, int type){
		int result = 0;
		for(Point p : shapeX1){
			    int i = p.y;
			    int j = p.x;
				//if (field.getValue(i, j) == Field.EMPTY) continue;

				// �����������
				boolean four = true;
				{
					// ��������������� ��������, ��� �� ����� ���� ������ ������
					int ny = i;
					int nx = j + 5;
					if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
						four = false;						
					} else
					if (field.getValue(i, j) != field.getValue(ny, nx)) {
						four = false;						
					}
				}
				if (four) {
					for(int k = 1; k < 5; k ++){
						int ny = i;
						int nx = j + k;
						if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
							four = false;
							break;
						}
						if (field.getValue(ny, nx) != type) {
							four = false;
							break;
						}
					}
				}
				if (four){
					result += 1;
				}

				// ���������
				four = true;
				{
					// ��������������� ��������, ��� �� ����� ���� ������ ������
					int ny = i + 5;
					int nx = j;
					if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
						four = false;						
					} else
					if (field.getValue(i, j) != field.getValue(ny, nx)) {
						four = false;						
					}
				}
				if (four) {
					for(int k = 1; k < 5; k ++){
						int ny = i + k;
						int nx = j;
						if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
							four = false;
							break;
						}
						if (field.getValue(ny, nx) != type) {
							four = false;
							break;
						}
					}
				}
				if (four){
					result += 1;
				}
				// ��������� 1
				four = true;
				{
					// ��������������� ��������, ��� �� ����� ���� ������ ������
					int ny = i + 5;
					int nx = j + 5;
					if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
						four = false;						
					} else
					if (field.getValue(i, j) != field.getValue(ny, nx)) {
						four = false;						
					}
				}
				if (four) {
					for(int k = 1; k < 5; k ++){
						int ny = i + k;
						int nx = j + k;
						if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
							four = false;
							break;
						}
						if (field.getValue(ny, nx) != type) {
							four = false;
							break;
						}
					}
				}
				if (four){
					result += 1;
				}
				
				// ��������� 2
				four = true;
				{
					// ��������������� ��������, ��� �� ����� ���� ������ ������
					int ny = i + 5;
					int nx = j - 5;
					if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
						four = false;						
					} else
					if (field.getValue(i, j) != field.getValue(ny, nx)) {
						four = false;						
					}
				}
				if (four) {
					for(int k = 1; k < 5; k ++){
						int ny = i + k;
						int nx = j - k;
						if (!((ny >= 0) && (ny < Field.SIZE) && (nx >= 0) && (nx < Field.SIZE))){
							four = false;
							break;
						}
						if (field.getValue(ny, nx) != type) {
							four = false;
							break;
						}
					}
				}
				if (four){
					result += 1;
				}
		}

		return result;
	}

	private Point victoryIn2Moves(int type){
		int[][] mx = field.getMatrix();
		// ���������� ������ ���
		for(Point cMove1 : shapeX2){
			boolean win = true;
			
			mx[cMove1.y][cMove1.x] = type;
			
			if (mx[1][0] == Field.ZERO){
				System.out.println("eee");
			}
			//	���������� �����
			for(Point zMove1 : shapeX2){
				if (mx[zMove1.y][zMove1.x] != Field.EMPTY) 
					continue;
				
				if (type == Field.CROSS) mx[zMove1.y][zMove1.x] = Field.ZERO; else
					mx[zMove1.y][zMove1.x] = Field.CROSS;
				
				// ������� ��� �� ���
				Field f = new Field(mx, type);
				mx[zMove1.y][zMove1.x] = Field.EMPTY;					

				if (countHalfOpened4(f, type) == 0){
					win = false;
					break;
				}
			}
			
			if (win){
				return cMove1;
			}

			mx[cMove1.y][cMove1.x] = Field.EMPTY;
			
		}
		return null;
	}
	
	public Point think(Field field) {

		this.field = field;

		createShape();
		
		System.out.println("Searching for a victory...");
		if (canWin())
			return win();
		System.out.println("Searching for a big danger...");
		if (canLose())
			return doNotLose();
		

		System.out.println("Searching for a victory in two moves");
		Point p = null;
		
		p = victoryIn2Moves(field.getCurrentMove());
		if (p != null){
			return p;
		}
		
		System.out.println("Can we lose in two moves?..");
		p = null;

		field.swapMove();
		p = victoryIn2Moves(field.getCurrentMove());
		field.swapMove();
		if (p != null){
			return p;
		}

		System.out.println("Searching for an attacking combination");
		p = null;
		
		p = combination(field.getCurrentMove());
		if (p != null){
			return p;
		}

		System.out.println("Can we lose because of combination?..");
		p = null;

		field.swapMove();
		p = combination(field.getCurrentMove());
		field.swapMove();
		if (p != null){
			return p;
		}
		
		
		
		System.out.println("Searching for an ability to grow up...");
		p = canGrow();
		if (p != null)
			return p;
		
		
		System.out.println("Just searching for a best place");
		return putInPosition();

	}

	public void interruptThinking() {
		running = false;		
	}

	public ArtificialIntelligence createInstance() {
		return new MediumAI();
	}

}