package ai;

import java.awt.Point;

import engine.ConnectionManager;
import engine.Field;
import engine.Properties;
import events.LogPlayedEvent;
import gui.MainFrame;
/**
 * ������� �����
 * @author ������
 *
 */
public class NetPlayer implements ArtificialIntelligence{

	private Point point = null;
	private String name = null;
	private volatile boolean running;
	
	public NetPlayer(String name){
		this.name = name;
	}
		
	public String getInformation() {
		return "Net Player";
	}

	public String getName() {
		return name;
	}

	public Point think(Field field) {
		running = true;
		point = null;
		
		while (running && ((point = ConnectionManager.getInstance().getMove()) == null)) ;
		if (Properties.getInstance().isActivateOnMove()){
			MainFrame.getInstance().activate();
		}
		return point;
	}

	public void logPlayed(LogPlayedEvent e) {
			point = e.getMove();
			
	}

	public void interruptThinking() {
		running = false;	
	}

	public ArtificialIntelligence createInstance() {
		return new NetPlayer(name);
	}


}
