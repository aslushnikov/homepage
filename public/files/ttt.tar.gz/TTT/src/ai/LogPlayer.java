package ai;

import java.awt.Point;

import engine.Field;
import events.LogPlayedEvent;
import events.LogPlayedListener;
import events.LogPlayedManager;
/**
 * ����� ��� �������
 * @author ������
 *
 */
public class LogPlayer implements ArtificialIntelligence, LogPlayedListener{

	private Point point = null;
	private String name = null;
	private volatile boolean running;
	
	public LogPlayer(){
		this.name = "�������������� ����";
		LogPlayedManager.addLogPlayedListener(this);
	}
	
	public LogPlayer(String name){
		this.name = name;
	}
	
	// ������ �� ������ =(
	private static boolean isFree;
	
	public static boolean isFree(){
		return isFree;
	}
	
	
	public String getInformation() {
		return "Log player";
	}

	public String getName() {
		return name;
	}

	public Point think(Field field) {
		running = true;
		point = null;
		
		//SystemMessager.sendMessage(new SystemMessage(this, SystemMessage.SPECIAL_LOGGER_MSG));
		isFree = true;
		while (running && (point == null)) {};
		return point;
	}

	public void logPlayed(LogPlayedEvent e) {
			isFree = false;
			point = e.getMove();			
	}

	public void interruptThinking() {
		running = false;		
		LogPlayedManager.removeLogPlayedListener(this);
	}

	public ArtificialIntelligence createInstance() {
		return null;
	}

}
