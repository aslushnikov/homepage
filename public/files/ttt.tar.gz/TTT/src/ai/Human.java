package ai;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import engine.Field;
import engine.Properties;
import gui.Screen;

/**
 * ����� ��� �������
 * 
 * @author ������
 * 
 */
public class Human implements ArtificialIntelligence, MouseListener {

	private Field field = null;

	private Point point = null;	

	private boolean move = false;

	private volatile boolean running;

	public Human() {
	}

	public String getInformation() {
		return "� ��� �� =)";
	}

	public String getName() {
		return Properties.getInstance().getPlayerName();
	}

	public Point think(Field field) {
		running = true;
		this.field = field;
		point = null;

		move = true;
		while (running && (point == null)) {
		}
		;
		move = false;

		return point;
	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
		if (!move)
			return;
		
		if (e.getButton() != MouseEvent.BUTTON1){
			return;
		}

		Screen screen = (Screen) e.getSource();

		int dX = screen.getWidth() / 2 - Screen.CELLSIZE * Field.SIZE / 2;
		int dY = screen.getHeight() / 2 - Screen.CELLSIZE * Field.SIZE / 2;

		if ((e.getPoint().x < dX) || (e.getPoint().y < dY)
				|| (e.getPoint().x > dX + Field.SIZE * Screen.CELLSIZE)
				|| (e.getPoint().y > dY + Field.SIZE * Screen.CELLSIZE))
			return;

		int x = (e.getPoint().x - dX) / Screen.CELLSIZE;
		int y = (e.getPoint().y - dY) / Screen.CELLSIZE;

		if (!((x >= 0) && (x < Field.SIZE) && (y >= 0) && (y < Field.SIZE)))
			return;

		if (field.getValue(y, x) == Field.EMPTY) {
			point = new Point(x, y);
		}
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void interruptThinking() {
		running = false;

	}

	public ArtificialIntelligence createInstance() {		
		return new Human();
	}
}
