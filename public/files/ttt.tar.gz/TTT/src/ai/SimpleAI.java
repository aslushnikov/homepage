package ai;

import java.awt.Point;

import engine.Field;

public class SimpleAI implements ArtificialIntelligence{

	private volatile boolean running;

	public String getInformation() {
		return null;
	}

	public String getName() {
		return null;
	}

	private Field field = null;
	
	private boolean canWin(){
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
					tmp.move(i, j);
			}
		}
		return false;
	}
	
	private Point win(){
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
					tmp.move(i, j);
				if (tmp.fiveInRaw()) return new Point(j, i);				
			}
		}
		return null;		
	}
	
	private boolean canLose(){
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
				if (tmp.getCurrentMove() == Field.CROSS) {
					tmp.setCurrentMove(Field.ZERO);
				} else {
					tmp.setCurrentMove(Field.CROSS);
				}
					tmp.move(i, j);
				if (tmp.fiveInRaw()) return true;				
			}
		}
		return false;		
	}
	
	private Point doNotLose(){
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
				if (tmp.getCurrentMove() == Field.CROSS) {
					tmp.setCurrentMove(Field.ZERO);
				} else {
					tmp.setCurrentMove(Field.CROSS);
				}
					tmp.move(i, j);
				if (tmp.fiveInRaw()) return new Point(j, i);				
			}
		}
		return null;				
	}
	
	private int winningMoves(Field field){
		int result = 0;
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
					tmp.move(i, j);
				if (tmp.fiveInRaw()) result += 1;				
			}
		}
		return result;		
	}
	
	private Point attackBuildOpened4(){
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
					tmp.move(i, j);
				if (winningMoves(tmp) > 1) return new Point(j, i); 				
			}
		}		
		return null;
	}
	
	private Point defendBuildOpened4(){		
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				Field tmp = (Field)field.clone();
				if (tmp.getCurrentMove() == Field.CROSS) {
					tmp.setCurrentMove(Field.ZERO);
				} else {
					tmp.setCurrentMove(Field.CROSS);
				}				
					tmp.move(i, j);
				if (winningMoves(tmp) > 1) return new Point(j, i); 				
			}
		}		
		return null;
	}
	
	private int countNeibours(Field field, int x, int y, int type){
		int result = 0;
		
		for(int k = -1; k <= 1; k ++){
			for(int l = -1; l <= 1; l ++){
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0) && (dy < Field.SIZE)){
					if (field.getValue(dy, dx) == type) result += 1;
				}
			}
		}
		
		return result;
	}

	private Point putInPosition(){
		int bestN = -1;
		Point bestP = null;
		for(int i = 0; i < Field.SIZE; i ++){
			for(int j = 0; j < Field.SIZE; j ++){
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				//Field tmp = (Field)field.clone();
				int type = field.getCurrentMove();
				if (type == Field.CROSS) {
					type = Field.ZERO; 
				} else {
					type = Field.CROSS;
				}
				
				int n = countNeibours(field, j, i, type);
				if (n > bestN) {
					bestN = n;
					bestP = new Point(j, i);
				}
			}
		}		
		System.out.println("best N is" + bestN);
		return bestP;				
	}
	
	public Point think(Field field) {
		this.field = field;
		System.out.println("1");
		if (canWin()) return win();
		System.out.println("2");
		if (canLose()) return doNotLose();
		System.out.println("3");
		Point p = attackBuildOpened4();
		if (p != null) return p;
		System.out.println("4");
		p = defendBuildOpened4();
		if (p != null) return p;
		
		
		System.out.println("5");
		return putInPosition();
	}

	public void interruptThinking() {
		// TODO Auto-generated method stub
		running = false;
		
	}

	public ArtificialIntelligence createInstance() {
		return new SimpleAI();
	}
	

}
