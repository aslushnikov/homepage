package ai;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import engine.Field;

public class SimpleSpeedUpAI implements ArtificialIntelligence {

	private volatile boolean running;

	public String getInformation() {
		return "����� ����� ������� ���������. ����� �������� ����������,\n" +
				"�� �� ����� ���������.\n" +
				"�����: �������� ������";
	}

	public String getName() {
		return "������";
	}

	private Field field = null;

	private ArrayList<Point> shape = null, shape1 = null;

	private boolean anyNeibour_x2(int x, int y) {
		for (int k = -2; k <= 2; k++) {
			for (int l = -2; l <= 2; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) != Field.EMPTY)
						return true;
				}
			}
		}

		return false;
	}

	private boolean anyNeibour_x1(int x, int y) {
		for (int k = -1; k <= 1; k++) {
			for (int l = -1; l <= 1; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) != Field.EMPTY)
						return true;
				}
			}
		}

		return false;
	}

	private void createShape() {
		shape = new ArrayList<Point>();
		shape1 = new ArrayList<Point>();
		for (int i = 0; i < Field.SIZE; i++) {
			for (int j = 0; j < Field.SIZE; j++) {
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				if (anyNeibour_x2(j, i))
					shape.add(new Point(j, i));
				if (anyNeibour_x1(j, i))
					shape1.add(new Point(j, i));
			}
		}
	}

	private boolean canWin() {
		for (Point p : shape1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			tmp.move(i, j);
			if (tmp.fiveInRaw())
				return true;

		}
		return false;
	}

	private Point win() {
		for (Point p : shape1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			tmp.move(i, j);
			if (tmp.fiveInRaw())
				return new Point(j, i);
		}
		return null;
	}

	private boolean canLose() {
		for (Point p : shape1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			if (tmp.getCurrentMove() == Field.CROSS) {
				tmp.setCurrentMove(Field.ZERO);
			} else {
				tmp.setCurrentMove(Field.CROSS);
			}
			tmp.move(i, j);
			if (tmp.fiveInRaw())
				return true;
		}

		return false;
	}

	private Point doNotLose() {
		for (Point p : shape1) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			if (tmp.getCurrentMove() == Field.CROSS) {
				tmp.setCurrentMove(Field.ZERO);
			} else {
				tmp.setCurrentMove(Field.CROSS);
			}
			tmp.move(i, j);
			if (tmp.fiveInRaw())
				return new Point(j, i);
		}

		return null;
	}

	private int winningMoves(Field field) {
		int result = 0;
		for (Point p : shape) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			tmp.move(i, j);
			if (tmp.fiveInRaw())
				result += 1;
		}

		return result;
	}

	private Point attackBuildOpened4() {
		Point result = null;
		for (Point p : shape) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			tmp.move(i, j);
			if (winningMoves(tmp) > 1)
				if (result == null)
					result = new Point(j, i);
				else if (new Random().nextInt() % 2 == 0)
					result = new Point(j, i);
		}

		return result;
	}

	private Point defendBuildOpened4() {
		for (Point p : shape) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			if (tmp.getCurrentMove() == Field.CROSS) {
				tmp.setCurrentMove(Field.ZERO);
			} else {
				tmp.setCurrentMove(Field.CROSS);
			}
			tmp.move(i, j);
			if (winningMoves(tmp) > 1)
				return new Point(j, i);
		}

		return null;
	}

	private Point canGrow() {
		Point result = null;
		for (Point p : shape) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			tmp.move(i, j);
			if (winningMoves(tmp) == 1)
				if (result == null)
					result = new Point(j, i);
				else if (new Random().nextInt() % 2 == 0)
					result = new Point(j, i);
		}

		return result;
	}

	private int countNeibours(Field field, int x, int y, int type) {
		int result = 0;

		for (int k = -1; k <= 1; k++) {
			for (int l = -1; l <= 1; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) == type)
						result += 1;
				}
			}
		}

		return result;
	}

	private Point putInPosition() {
		int bestN = -1;
		Point bestP = null;
		for (Point p : shape) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			int type = field.getCurrentMove();
			if (type == Field.CROSS) {
				type = Field.ZERO;
			} else {
				type = Field.CROSS;
			}

			int n = countNeibours(field, j, i, type);
			if (n > bestN) {
				bestN = n;
				bestP = new Point(j, i);
			} else if ((n == bestN) && (new Random().nextInt() % 2 == 0)) {
				bestN = n;
				bestP = new Point(j, i);
			}
		}

		System.out.println("best N is " + bestN);

		if (bestN == -1) {
			bestP = new Point(Field.SIZE / 2, Field.SIZE / 2);
		}

		return bestP;
	}

	public Point think(Field field) {

		this.field = field;

		createShape();
		System.out.println("Shape contains " + shape.size() + " elements");

		System.out.println("Searching for a victory...");
		if (canWin())
			return win();
		System.out.println("Searching for a big danger...");
		if (canLose())
			return doNotLose();
		System.out.println("Searching for an attack...");
		Point p = attackBuildOpened4();
		if (p != null)
			return p;
		System.out.println("Searching for a danger...");
		p = defendBuildOpened4();
		if (p != null)
			return p;

		System.out.println("Searching for an ability to grow up...");
		p = canGrow();
		if (p != null)
			return p;

		System.out.println("Just searching for a best place");
		return putInPosition();
	}

	public void interruptThinking() {
		running = false;

	}

	public ArtificialIntelligence createInstance() {
		return new SimpleSpeedUpAI();
	}

}
