package ai;

import java.awt.Point;
import java.util.Random;

import engine.Field;

public class RandomAI implements ArtificialIntelligence{
	private volatile boolean running = true;
	
	public String getInformation() {
		return null;
	}

	public String getName() {
		return "�������";
	}

	public Point think(Field field) {
		do{
			int x = new Random().nextInt(Field.SIZE);
			int y = new Random().nextInt(Field.SIZE);
			if (field.getValue(y, x) == Field.EMPTY) return new Point(x, y);;
		}while (running);
		return null;
	}

	public void interruptThinking() {
		running = false;
		
	}

	public ArtificialIntelligence createInstance() {
		return new RandomAI();
	}

}
