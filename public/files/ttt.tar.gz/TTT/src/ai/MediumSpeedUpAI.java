package ai;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import engine.Field;

public class MediumSpeedUpAI implements ArtificialIntelligence {

	private volatile boolean running;

	public String getInformation() {
		return "���������, ����� �������������� �������. \n" +
				"����� ���������� �� �����������,\n" +
				"�� �������� �����, �� ���� �� ����� ���������.\n" +
				"�����: �������� ������";
	}

	public String getName() {
		return "�����";
	}

	private Field field = null;

	private ArrayList<Point> shapeX2 = null, shapeX1 = null;

	private boolean anyNeibourX2(Field field, int x, int y) {
		for (int k = -2; k <= 2; k++) {
			for (int l = -2; l <= 2; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) != Field.EMPTY)
						return true;
				}
			}
		}

		return false;
	}

	private boolean anyNeibourX1(Field field, int x, int y) {
		for (int k = -1; k <= 1; k++) {
			for (int l = -1; l <= 1; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) != Field.EMPTY)
						return true;
				}
			}
		}

		return false;
	}

	private ArrayList<Point> createShapeX2(Field field) {
		ArrayList<Point> shape = new ArrayList<Point>();
		for (int i = 0; i < Field.SIZE; i++) {
			for (int j = 0; j < Field.SIZE; j++) {
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				if (anyNeibourX2(field, j, i))
					shape.add(new Point(j, i));
				// if (anyNeibourX1(field, j, i))
				// shape.add(new Point(j, i));
			}
		}
		return shape;
	}

	private ArrayList<Point> createShapeX1(Field field) {
		ArrayList<Point> shape = new ArrayList<Point>();
		for (int i = 0; i < Field.SIZE; i++) {
			for (int j = 0; j < Field.SIZE; j++) {
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				if (anyNeibourX1(field, j, i))
					shape.add(new Point(j, i));
				// if (anyNeibourX1(field, j, i))
				// shape.add(new Point(j, i));
			}
		}
		return shape;
	}

	private Point fiveIn1Move(int type) {
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			Field tmp = (Field) field.clone();
			tmp.setCurrentMove(type);
			tmp.move(i, j);
			if (tmp.fiveInRaw())
				return p;
		}
		return null;
	}

	private int countHalfOpened4(Field field, int type) {
		int result = 0;
		ArrayList<Point> shapeX1 = new ArrayList<Point>();
		for (int i = 0; i < Field.SIZE; i++) {
			for (int j = 0; j < Field.SIZE; j++) {
				if (field.getValue(i, j) != Field.EMPTY) {
					continue;
				}
				if (anyNeibourX1(field, j, i))
					shapeX1.add(new Point(j, i));
			}
		}

		for (Point p : shapeX1) {
			int i = p.y;
			int j = p.x;

			if (field.getValue(i, j) != Field.EMPTY)
				continue;

			Field tmp = (Field) field.clone();
			tmp.setCurrentMove(type);
			tmp.move(i, j);
			if (type == Field.CROSS) {
				if (tmp.fiveCrossesInRaw())
					result += 1;
			} else {
				if (tmp.fiveZeroesInRaw())
					result += 1;
			}
		}

		return result;
	}

	private Point victoryIn2Moves(int type) {
		for (Point move : shapeX2) {
			Field tmp = (Field) field.clone();
			tmp.setCurrentMove(type);
			tmp.move(move.y, move.x);
			if (countHalfOpened4(tmp, type) > 1) {
				return move;
			}
		}
		return null;
	}

	private boolean inSquare(Point p1, Point p2, int sSize) {
		return (Math.abs(p1.x - p2.x) < sSize)
				&& (Math.abs(p1.y - p2.y) < sSize);
	}

	private Point victoryIn3Moves(int type) {
		for (Point cMove1 : shapeX2) {

			boolean winning = true;

			Field f1 = (Field) field.clone();
			f1.setCurrentMove(type);
			f1.move(cMove1.y, cMove1.x);

			for (Point zMove : shapeX2) {
				// ���� ��������������� ���� ����� ��� ������� ��� ��������
				if (!inSquare(zMove, cMove1, 5))
					continue;
				// ���� ���� ��� ������
				if (f1.getValue(zMove.y, zMove.x) != Field.EMPTY)
					continue;

				Field f2 = (Field) f1.clone();
				f2.swapMove();
				f2.move(zMove.y, zMove.x);

				boolean defendering = true;

				for (Point cMove2 : shapeX2) {
					if (!inSquare(cMove2, cMove1, 5))
						continue;
					if (f2.getValue(cMove2.y, cMove2.x) != Field.EMPTY)
						continue;

					Field f3 = (Field) f2.clone();
					f3.swapMove();

					f3.move(cMove2.y, cMove2.x);
					if (countHalfOpened4(f3, type) > 1) {
						defendering = false;
						break;
					}
				}
				if (defendering) {
					winning = false;
					break;
				}
			}

			if (winning) {
				return cMove1;
			}

		}
		return null;
	}

	private Point speedUpVictoryIn3Moves(int type) {
		int[][] mx = field.getMatrix();
		for (Point cMove1 : shapeX2) {

			boolean winning = true;

			mx[cMove1.y][cMove1.x] = type;

			for (Point zMove : shapeX2) {
				// ���� ��������������� ���� ����� ��� ������� ��� ��������
				if (!inSquare(zMove, cMove1, 5))
					continue;
				// ���� ���� ��� ������
				if (mx[zMove.y][zMove.x] != Field.EMPTY)
					continue;

				if (type == Field.CROSS)
					mx[zMove.y][zMove.x] = Field.ZERO;
				else
					mx[zMove.y][zMove.x] = Field.CROSS;

				boolean defendering = true;

				for (Point cMove2 : shapeX2) {
					if (!inSquare(cMove2, cMove1, 5))
						continue;
					if (mx[cMove2.y][cMove2.x] != Field.EMPTY)
						continue;

					mx[cMove2.y][cMove2.x] = type;

					Field f3 = new Field(mx, type);

					mx[cMove2.y][cMove2.x] = Field.EMPTY;

					if (countHalfOpened4(f3, type) > 1) {
						defendering = false;
						break;
					}
				}
				mx[zMove.y][zMove.x] = Field.EMPTY;
				if (defendering) {
					winning = false;
					break;
				}
			}
			mx[cMove1.y][cMove1.x] = Field.EMPTY;

			if (winning) {
				return cMove1;
			}

		}
		return null;
	}

	private int countNeibours(Field field, int x, int y, int type) {
		int result = 0;

		for (int k = -1; k <= 1; k++) {
			for (int l = -1; l <= 1; l++) {
				int dx = x + k;
				int dy = y + l;
				if ((dx >= 0) && (dx < Field.SIZE) && (dy >= 0)
						&& (dy < Field.SIZE)) {
					if (field.getValue(dy, dx) == type)
						result += 1;
				}
			}
		}

		return result;
	}

	private Point justAMove() {
		int zBestN = -1;
		Point zBestP = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			// Field tmp = (Field)field.clone();
			int type = field.getCurrentMove();
			if (type == Field.CROSS) {
				type = Field.ZERO;
			} else {
				type = Field.CROSS;
			}

			int n = countNeibours(field, j, i, type);
			if (n > zBestN) {
				zBestN = n;
				zBestP = new Point(j, i);
			} else if ((n == zBestN) && (new Random().nextInt() % 2 == 0)) {
				zBestN = n;
				zBestP = new Point(j, i);
			}
		}

		int cBestN = -1;
		Point cBestP = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			// Field tmp = (Field)field.clone();
			int type = field.getCurrentMove();

			int n = countNeibours(field, j, i, type);
			if (n > cBestN) {
				cBestN = n;
				cBestP = new Point(j, i);
			} else if ((n == cBestN) && (new Random().nextInt() % 2 == 0)) {
				cBestN = n;
				cBestP = new Point(j, i);
			}
		}

		int attBestN = -1;
		Point attBestP = null;
		for (Point p : shapeX2) {
			int i = p.y;
			int j = p.x;
			if (field.getValue(i, j) != Field.EMPTY) {
				continue;
			}
			// Field tmp = (Field)field.clone();
			int type = field.getCurrentMove();
			if (type == Field.CROSS) {
				type = Field.ZERO;
			} else {
				type = Field.CROSS;
			}

			int n1 = countNeibours(field, j, i, type), n2 = countNeibours(
					field, j, i, field.getCurrentMove());
			if (n2 - n1 > attBestN) {
				attBestN = n2 - n1;
				attBestP = new Point(j, i);
			} else if ((n2 - n1 == attBestN)
					&& (new Random().nextInt() % 2 == 0)) {
				attBestN = n2 - n1;
				attBestP = new Point(j, i);
			}
		}

		// System.out.println("best N is " + zBestN);
		/*
		 * if ((cBestN >= zBestN) && (cBestN != -1)) return cBestP;
		 * 
		 * if (zBestN == -1) { zBestP = new Point(Field.SIZE / 2, Field.SIZE /
		 * 2); }
		 */
		if (attBestN >= 2)
			return attBestP;

		if (zBestN == -1) {
			zBestP = new Point(Field.SIZE / 2, Field.SIZE / 2);
		}
		return zBestP;
	}

	public Point think(Field field) {
		this.field = field;

		// ������ ������
		shapeX1 = createShapeX1(field);
		shapeX2 = createShapeX2(field);
		System.out.println("***X1 Shape size is " + shapeX1.size() + "***");
		System.out.println("***X2 Shape size is " + shapeX2.size() + "***");

		Point result = null;

		// ���������, ����� �� �������� � ���� ���
		result = fiveIn1Move(field.getCurrentMove());
		if (result != null) {
			System.out.println("	[Immediate Victory]");
			return result;
		} else {
			System.out.println("no Immediate Victory");
		}

		// ���������, ����� �� ��������� � ���� ���
		field.swapMove();
		result = fiveIn1Move(field.getCurrentMove());
		field.swapMove();
		if (result != null) {
			System.out.println("	[Immediate Defeat]");
			return result;
		} else {
			System.out.println("no Immediate defeat");
		}

		// ��������� ����� �� �������� � ��� ����
		result = victoryIn2Moves(field.getCurrentMove());
		if (result != null) {
			System.out.println("	[Two moves Victory]");
			return result;
		} else {
			System.out.println("no victory in two moves");
		}

		// ��������� ������ �� � ��� �������� � ��� ����
		field.swapMove();
		result = victoryIn2Moves(field.getCurrentMove());
		field.swapMove();
		if (result != null) {
			System.out.println("	[Defeated from victory in two moves]");
			return result;
		} else {
			System.out.println("Cannot be defeated in two moves");
		}

		// ��������� ����� �� �������� � ��� ����
		result = speedUpVictoryIn3Moves(field.getCurrentMove());
		if (result != null) {
			System.out.println("	[THREE(!) moves Victory]");
			return result;
		} else {
			System.out.println("no victory in THREE moves");
		}

		// ��������� ������ �� � ��� �������� � ��� ����
		field.swapMove();
		result = speedUpVictoryIn3Moves(field.getCurrentMove());
		field.swapMove();
		if (result != null) {
			System.out.println("	[Defeated from victory in THREE(!) moves]");
			return result;
		} else {
			System.out.println("Cannot be defeated in three moves");
		}

		return justAMove();
	}

	public void interruptThinking() {
		running = false;

	}

	public ArtificialIntelligence createInstance() {
		return new MediumSpeedUpAI();
	}
}
