package events;

public interface SystemListener {
	
	public void purchaseMessage(SystemMessage msg);
	
}
