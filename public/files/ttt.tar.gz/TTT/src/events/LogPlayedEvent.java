package events;

import java.awt.Point;

public class LogPlayedEvent {
	private Point move = null;
	private int type = 0;
	public LogPlayedEvent(Point point, int type){
		this.move = point;
		this.type = type;
	}
	
	public Point getMove(){
		return move;
	}
	
	public int getType(){
		return type;
	}
}
