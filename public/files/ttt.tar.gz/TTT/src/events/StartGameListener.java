package events;

public interface StartGameListener {
	
	public void gameStarted(StartGameCommand e);
	
}
