package events;

import ai.ArtificialIntelligence;

public class MovePerformedAction {
	private ArtificialIntelligence player;
	private int x, y;
	public MovePerformedAction(ArtificialIntelligence player, int x, int y){
		this.player = player;
		this.x = x;
		this.y = y;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public ArtificialIntelligence getPlayer(){
		return player;
	}
}
