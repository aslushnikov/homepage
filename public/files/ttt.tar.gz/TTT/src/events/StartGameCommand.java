package events;

import engine.Game;

public class StartGameCommand {
	private Game game = null;
	
	public StartGameCommand(Game game){
		this.game = game;		
	}
	
	public Game getGame(){
		return game;
	}
}
