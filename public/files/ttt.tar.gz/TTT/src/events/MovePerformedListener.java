package events;

public interface MovePerformedListener {
	public void movePerformed(MovePerformedAction arg);
}
