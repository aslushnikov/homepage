package events;

public class SystemMessage {
	public static final int CUSTOM_MSG = 0;
	public static final int GAME_STARTED = 1;
	public static final int GAME_FINISHED = 2;
	public static final int GAME_INTERRUPTED = 3;
	public static final int GAME_REPEATED = 4;
	public static final int LOG_LOADED = 5;
	public static final int LOG_SAVED = 6;
	public static final int SIDES_SWAPPED = 7;
	public static final int CONNECTION_ESTABLISHED = 8;
	public static final int CONNECTION_LOST = 9;
	public static final int CANNOT_CREATE_SERVER = 10;
	public static final int NET_MESSAGE_RECIEVED = 11;
	public static final int CONNECTION_CLOSED = 12;
		
	private Object who;
	private Object msg;
	private int type;
	
	public Object getMessage() {
		return msg;
	}

	public Object getSource() {
		return who;
	}

	public int getType(){
		return type;
	}

	public SystemMessage(Object who, int type, Object msg){
		this.who = who;
		this.msg = msg;
		this.type = type;
	}
	
	public SystemMessage(Object who, int type){
		this.who = who;
		this.msg = null;
		this.type = type;
	}	
}
