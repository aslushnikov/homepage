package events;

public interface LogPlayedListener {
	public void logPlayed(LogPlayedEvent e);

}
