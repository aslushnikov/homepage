package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import ai.Human;
import ai.NetPlayer;
import engine.ConnectionManager;
import engine.Game;
import engine.NetMessage;
import engine.Properties;
import events.MovePerformedAction;
import events.MovePerformedListener;
import events.MovePerformedManager;
import events.StartGameCommand;
import events.StartGameCommander;
import events.SystemListener;
import events.SystemMessage;
import events.SystemMessager;

public class NetGame extends JInternalFrame implements ActionListener, 
		SystemListener, MovePerformedListener {

	private final static String CONFIG_FILE = "servers.opt";
	
	private JList serverList;

	JScrollPane sp;

	private JButton connect, create, add, delete, cancel1, cancel2, interrupt;
	
	JPanel notConnectedPanel, connectedPanel;
	JLabel statusTitle;

	NetPlayer netPlayer;
	
	private ArrayList<InetAddress> servers;

	private ConnectionManager connectionManager;

	private void refreshServerList() {
		Vector<InetAddress> vect = new Vector<InetAddress>();
		try {
			vect.add(InetAddress.getLocalHost());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		vect.addAll(servers);

		serverList = new JList(vect);
		sp.setViewportView(serverList);
	}

	private static NetGame instance=null;
	
	public static NetGame getInstance(){
		if (instance == null){
			instance = new NetGame();
		}
		return instance;
	}
	
	private void saveServers(){
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(CONFIG_FILE)));
			oos.writeObject(servers);
			oos.flush();
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	private void readServers(){
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(CONFIG_FILE)));
			servers = (ArrayList<InetAddress>)ois.readObject();
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}
	
	CardLayout cardLayout;
	
	private class EscapeKeyListener implements KeyListener{
		private JInternalFrame frame = null;
		public EscapeKeyListener(JInternalFrame frame){
			this.frame = frame;			
		}

		public void keyPressed(KeyEvent e) {			
			
		}

		public void keyReleased(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_ESCAPE){
				frame.setVisible(false);
			}
		}

		public void keyTyped(KeyEvent e) {
		}
		
	}
	
	KeyListener escapeKey;
	
	private NetGame() {
		super("������� ����");
		
		escapeKey = new EscapeKeyListener(this);
		
		SystemMessager.addSystemListener(this);
		
		MovePerformedManager.addMovePerformedListener(this);
		
		this.connectionManager = ConnectionManager.getInstance();
		
		cardLayout = new CardLayout(2, 2);
		
		this.setLayout(cardLayout);
		

		notConnectedPanel = new JPanel(new BorderLayout(2, 2));
		//��������� �������
		readServers();
		// ������ ��������, ������� ������������, ����� ���������� �� �����������
		{
			// ������ ��������
			Vector<InetAddress> vect = new Vector<InetAddress>();
			try {
				vect.add(InetAddress.getLocalHost());
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			vect.addAll(servers);
			
			serverList = new JList(vect);
			serverList.addKeyListener(escapeKey);
			if (vect.size() > 0){
				serverList.setSelectedIndex(0);
			}
			
			sp = new JScrollPane(serverList);
			sp.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			notConnectedPanel.add(sp, BorderLayout.CENTER);

			connect = new JButton("��������������");
			connect.addActionListener(this);
			connect.addKeyListener(escapeKey);
			
			create = new JButton("<html><font color=green>�������</font>");
			create.addActionListener(this);
			create.addKeyListener(escapeKey);
			
			add = new JButton(new ImageIcon("add.gif"));
			add.addActionListener(this);
			add.addKeyListener(escapeKey);
			
			delete = new JButton(new ImageIcon("remove.gif"));
			delete.addActionListener(this);
			delete.addKeyListener(escapeKey);
			cancel1 = new JButton("������");
			cancel1.addActionListener(this);
			cancel1.addKeyListener(escapeKey);

			JPanel buttons = new JPanel(new GridLayout(4, 1));

			JPanel addDeleteButtons = new JPanel(new GridLayout(1, 2));
			addDeleteButtons.add(add);
			addDeleteButtons.add(delete);

			buttons.add(create);
			buttons.add(connect);
			buttons.add(addDeleteButtons);
			buttons.add(cancel1);

			notConnectedPanel.add(buttons, BorderLayout.WEST);
		}

		connectedPanel = new JPanel(new GridLayout(2, 1));
		{
			interrupt = new JButton("<html><font color = red>��������� ����������</font>");
			interrupt.addActionListener(this);
			interrupt.addKeyListener(escapeKey);
			
			JPanel statusPanel = new JPanel(new GridLayout(2, 1));
			
			statusTitle = new JLabel("��������� ���", new ImageIcon("connected.gif"), JLabel.HORIZONTAL);
			statusPanel.add(statusTitle);
			statusPanel.add(interrupt);
			statusPanel.setBorder(BorderFactory.createTitledBorder("���������� c:"));
			
			connectedPanel.add(statusPanel);
			
			JPanel labels = new JPanel(new GridLayout(3, 1));
			JLabel info1 = new JLabel(), info2 = new JLabel();;
			info1.setText("���� �������� ����� ������� ������ \"������\"");
			info2.setText("��� ���� ��������� � ���� ��� >> ���");
			cancel2 = new JButton("C�����");
			cancel2.addActionListener(this);
			cancel2.addKeyListener(escapeKey);
			
			labels.add(info1);
			labels.add(info2);
			labels.add(cancel2);
						
			connectedPanel.add(labels);
			
		}
		

		this.add(notConnectedPanel, "Connection Manager");
		this.add(connectedPanel, "Connection Status");
		
		//TODO ������� �������� ������ �� ������� ������� ESC!!!!
		/*
		this.addKeyListener(this);		
		notConnectedPanel.addKeyListener(this);
		connectedPanel.addKeyListener(this);*/				
						
		this.setSize(440, 190);
//		System.out.println(MainFrame.getInstance().getWidth() + " " + MainFrame.getInstance().getHeight());
	}

	private boolean firstAfterConnection = false;
	
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		if (obj == cancel1) {
			this.setVisible(false);
		}
		if (obj == cancel2) {
			if (firstAfterConnection){
				netPlayer = new NetPlayer(connectionManager.getClientName());
				if (connectionManager.getServerState() == ConnectionManager.STARTED){
					StartGameCommander.fireEvent(new StartGameCommand(new Game(new Human(), netPlayer)));
				} else {
					StartGameCommander.fireEvent(new StartGameCommand(new Game(netPlayer, new Human())));				
				}									
				cancel2.setText("������");
				firstAfterConnection = false;
			}
			this.setVisible(false);			
			
			//Chat.getInstance().setVisible(true);
		}
		if (obj == delete) {
			int[] idx = serverList.getSelectedIndices();
			for (int i = idx.length - 1; i >= 0; i--) {
				if (idx[i] == 0) {
					JOptionPane.showMessageDialog(null, "��������� ���� �� ����� ���� �����", "C������ ����", JOptionPane.INFORMATION_MESSAGE);
				} else {
					servers.remove(idx[i] - 1);
				}
			}
			saveServers();
			refreshServerList();
		}

		if (obj == interrupt) {
			connectionManager.sendMessage(new NetMessage(NetMessage.CLOSE_CONNECTION));
			connectionManager.closeConnection();
			connect.setEnabled(true);
			create.setText("<html><font color=green>�������</font>");
			cardLayout.show(this.getContentPane(), "Connection Manager");
		}
		if (obj == add) {
			String host = JOptionPane.showInputDialog(null,
					"������� ����� ������ �������");
			if (host == null) {
				return;
			}
			try {
				servers.add(InetAddress.getByName(host));
				saveServers();
				refreshServerList();

			} catch (UnknownHostException e1) {
				JOptionPane.showMessageDialog(null, "�������� ��� �������",
						"������", JOptionPane.ERROR_MESSAGE);
			}
		}
		if (obj == create) {
			if (connectionManager.getServerState() == ConnectionManager.STOPPED) {
				connectionManager.startServer();
				create.setText("<html><font color=red>����������</font>");
				connect.setEnabled(false);					
			} else {
				connectionManager.closeConnection();
				create.setText("<html><font color=green>�������</font>");
				connect.setEnabled(true);
			}
		}

		if (obj == connect) {
			if (serverList.getSelectedIndices().length != 1) {
				JOptionPane.showMessageDialog(null, "�������� ���� ������",
						"������", JOptionPane.ERROR_MESSAGE);
				return;
			}
			Vector<InetAddress> vect = new Vector<InetAddress>();
			try {
				vect.add(InetAddress.getLocalHost());
			} catch (UnknownHostException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
			vect.addAll(servers);
			
			connectionManager.connect(vect.get(serverList.getSelectedIndex()));
		}
	}

	public void purchaseMessage(SystemMessage msg) {
		if (msg.getType() == SystemMessage.CONNECTION_ESTABLISHED) {
			firstAfterConnection = true;
			cancel2.setText("<html><font color = green>������ ����</font>");
			statusTitle.setText(connectionManager.getClientName());
			cardLayout.show(this.getContentPane(), "Connection Status");
			this.setVisible(true);
			//this.setSize(440, 170);
		}
		if (msg.getType() == SystemMessage.CONNECTION_LOST) {
			connect.setEnabled(true);
			create.setText("<html><font color=green>�������</font>");			
			cardLayout.show(this.getContentPane(), "Connection Manager");				
		}
		if (msg.getType() == SystemMessage.CANNOT_CREATE_SERVER){
			connect.setEnabled(true);
			create.setText("<html><font color=green>�������</font>");			
		}
	}
	
	/**
	 * ������������� ����� ����������� ������� ����
	 */
	public void showForm(){		
		if (connectionManager.getConnectionState() == ConnectionManager.CONNECTED){
			cardLayout.show(this.getContentPane(), "Connection Status");
		} else {
			cardLayout.show(this.getContentPane(), "Connection Manager");							
		}
		this.setVisible(true);
	}

	public void movePerformed(MovePerformedAction arg) {
		this.setVisible(false);
		if (connectionManager.getConnectionState() != ConnectionManager.CONNECTED) {
			return;
		}
		if (arg.getPlayer() instanceof Human){
			connectionManager.sendMessage(new NetMessage(NetMessage.MOVE, new Point(arg.getX(), arg.getY())));
		}
	}

}
