package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import engine.ConnectionManager;
import engine.NetMessage;
import engine.Properties;

public class Chat extends JPanel implements ActionListener{
	
	private void setTags(char tag){
		if (editor.getSelectedText() == null){
			editor.setText(editor.getText() + "<" + tag + "></" + tag + ">");
			return;
		}
		
		StringBuilder text = new StringBuilder(editor.getText());
		text.insert(editor.getSelectionEnd(), "</" + tag + ">");
		text.insert(editor.getSelectionStart(), "<" + tag + ">");
		editor.setText(text.toString());
	}
	
	private void sendMessage(){
		//System.out.println(editor.getText());
		if (editor.getText().equals("")) return;
		String text = editor.getText();

		// ���������� ���������
		ConnectionManager.getInstance().sendMessage(new NetMessage(NetMessage.CHAT_MESSAGE, text));
		ChatMessage m = new ChatMessage(ChatMessage.YOU, text);
		msg.add(m);
		generateText();
		editor.setText("");
	}
	
	private class EditorKeyListener implements KeyListener{
		
		private JPanel frame;
		
		public EditorKeyListener(JPanel frame){
			this.frame = frame;
		}
		
		public void keyPressed(KeyEvent e) {

			if ((e.getKeyCode() == KeyEvent.VK_B) && (e.getModifiersEx() == KeyEvent.CTRL_DOWN_MASK)){
				setTags('b');
			}
			if ((e.getKeyCode() == KeyEvent.VK_I) && (e.getModifiersEx() == KeyEvent.CTRL_DOWN_MASK)){
				setTags('i');
			}
			if ((e.getKeyCode() == KeyEvent.VK_U) && (e.getModifiersEx() == KeyEvent.CTRL_DOWN_MASK)){
				setTags('u');
			}
		}

		public void keyReleased(KeyEvent e) {
		}

		public void keyTyped(KeyEvent e) {
		}
		
	}
	
	private class ChatMessage{
		public static final boolean YOU = true;
		public static final boolean OPPONENT = false;
		
		private String msg = null;
		private boolean author;
		private Date date = null;
		
		public ChatMessage(boolean  author, String msg){
			this.author = author;
			this.msg = msg;	
			date = new Date();
		}
		
		public String getMessage(){
			return msg;
		}
		
		public boolean getAuthor(){
			return author;
		}
		
		public Date getDate(){
			return date;
		}
	}
	
	ArrayList<ChatMessage> msg = null; 
	
	private static Chat instance = null;
	
	public static Chat getInstance(){
		if (instance == null){
			instance = new Chat();
		}
		return instance;
	}
	
	JEditorPane pane;
	JTextField editor;
	JPanel buttons;
	JButton bold, italic, underlined, enter;
	
	private void generateText(){
		SimpleDateFormat dateFormat = new SimpleDateFormat(" [hh:mm:ss] ");

		String text = "<html>";
		for(ChatMessage s : msg){
			String date = dateFormat.format(s.getDate());						
			if (s.getAuthor() == ChatMessage.YOU){
				text += "<font color = red><b>";
				text += Properties.getInstance().getPlayerName();
				text += date;
				text += "</b></font>";
			} else {
				text += "<font color = blue><b>";
				text += ConnectionManager.getInstance().getClientName();
				text += date;
				text += "</b></font>";
			}
			text += "<font color = black>" + s.getMessage() + "</font><br>";
		}
		//text += "<a name = \"last\"></a>";
		pane.setText(text);
		//pane.scrollToReference("last");
		//pane.scrollRectToVisible(new Rectangle(pane.getWidth(), pane.getHeight()));
		pane.setCaretPosition(pane.getDocument().getLength());
	}
	
	public void setEnabled(boolean state){
		bold.setEnabled(state);
		italic.setEnabled(state);
		underlined.setEnabled(state);
		enter.setEnabled(state);
		editor.setEnabled(state);
	}
	
	private Chat(){
		super(new BorderLayout(0, 1));
		pane = new JEditorPane("text/html;Content-Type=windows-1251", "");
		pane.setEditable(false);
		pane.setPreferredSize(new Dimension(100, 100));
		
		JScrollPane sp = new JScrollPane(pane);
		
		buttons = new JPanel(new GridLayout(1, 4));
		
		enter = new JButton("<html><font color = green> >> </font>");
		enter.addActionListener(this);
		
		bold = new JButton("<html><font size = 3><b>B</b></font>");
		bold.addActionListener(this);
		
		italic = new JButton("<html><font size = 3><i>i</i></font>");
		italic.addActionListener(this);
		
		underlined = new JButton("<html><font size = 3><u>u</u></font>");
		underlined.addActionListener(this);
		
		buttons.add(enter);
		buttons.add(bold);
		buttons.add(italic);
		buttons.add(underlined);
		
		
		editor = new JTextField();
		
		editor.addActionListener(this);
		editor.addKeyListener(new EditorKeyListener(this));
		
		setEnabled(false);

		JPanel bottom = new JPanel(new BorderLayout());
		bottom.add(editor, BorderLayout.CENTER);
		bottom.add(buttons, BorderLayout.EAST);
		
		msg = new ArrayList<ChatMessage>();
				
		this.add(sp, BorderLayout.CENTER);
		this.add(bottom, BorderLayout.SOUTH);
		this.setPreferredSize(new Dimension(100, 100));
		this.setVisible(false);
	}

	public void clientMessage(String text){
		// ���� ����� ��������� �� ������� ������ ��������� � ���
		if (Properties.getInstance().isActivateOnMessage()){
			MainFrame.getInstance().activate();
		}

		ChatMessage m = new ChatMessage(ChatMessage.OPPONENT, text);
		msg.add(m);
		generateText();
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == editor){
			sendMessage();
		}
		if (e.getSource() == enter){
			sendMessage();
		}
		if (e.getSource() == bold){
			setTags('b');
		}
		if (e.getSource() == italic){
			setTags('i');
		}		
		if (e.getSource() == underlined){
			setTags('u');
		}				
	}
}
